# <center><b><u> Assignment 1 </u></b></center>
#### <center> Ayush Maurya | 2021115004 </center>

<br>
<br>
<br>

## <u> Question-1 </u>
This will overwrite on the file quotes.txt, so i have included an extra file quote.txt that none of the scripts will use.
Filename: q1.sh

## <u> Question-2 </u>
This doesn't overwrite but prints it on the screen. But it uses the file edited previously.
Filename: q2.sh

## <u> Question-3 </u>
The output is printed on the screen. No file is edited. The subparts in the bash file starts with the comments '## \<subpart number\>'
Filename: q3.sh

## <u> Question-4 </u>
The sorted array is printed with each number seperated with spaces.
Filename: q4.sh

## <u> Question-1 </u>
An input is needed here. According to the question please enter 'Helloo' as input.
Filename: q5.sh

## <u> Github Repo Link </u>
